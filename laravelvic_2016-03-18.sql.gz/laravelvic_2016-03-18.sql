# ************************************************************
# Sequel Pro SQL dump
# Version 4529
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Hôte: 127.0.0.1 (MySQL 5.5.38)
# Base de données: laravelvic
# Temps de génération: 2016-03-18 18:24:24 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Affichage de la table comments
# ------------------------------------------------------------

DROP TABLE IF EXISTS `comments`;

CREATE TABLE `comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `comments_post_id_foreign` (`post_id`),
  KEY `comments_user_id_foreign` (`user_id`),
  CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `comments_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;

INSERT INTO `comments` (`id`, `post_id`, `user_id`, `content`, `created_at`, `updated_at`)
VALUES
	(1,8,9,'Ratione accusamus sequi rerum quidem deleniti sapiente reiciendis. Voluptate vitae et ut id. Quaerat saepe et asperiores aperiam eligendi molestiae minima. Qui accusamus quia placeat itaque.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(2,2,2,'Cum doloremque recusandae provident minus. Et iusto quo aspernatur dolorem nulla est. Cumque facere est et temporibus. Vitae aspernatur qui quia vitae et.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(3,18,7,'Et labore molestiae dolores fugiat et quia ut delectus. Consectetur ut sunt aliquam ab numquam. Dolorem unde odio at qui omnis iure. Et rerum ut consequatur.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(4,3,6,'Amet molestiae non et delectus autem pariatur. Vel suscipit ullam soluta quia autem. Earum modi dolores sed cumque autem nihil ut. Vitae commodi labore ducimus distinctio omnis in.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(5,16,9,'Sint aut autem corporis similique aut ab. Omnis quia atque aliquam ex rem. Error ut necessitatibus est ea laborum et autem. Possimus sed quae et quia perspiciatis non. Expedita est sit vel occaecati.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(6,5,2,'Ut enim rerum repellendus qui. Ea harum dolores ipsam similique et blanditiis rerum veritatis.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(7,8,4,'Culpa nam numquam eligendi velit iste. Tenetur aut nesciunt laboriosam aperiam. Qui et molestiae natus sit est. Animi ut provident autem mollitia architecto quis atque.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(8,14,10,'Omnis reiciendis distinctio laudantium similique veniam quis beatae. Eos dignissimos similique sunt. Magni saepe et qui. Ut eligendi adipisci molestiae recusandae minima eum quia ea.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(9,20,5,'Exercitationem alias dignissimos dolorem. Labore sed illum expedita repellat eius sapiente molestiae. Ullam quis corrupti dolorum culpa. Asperiores illo facilis dolor at inventore.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(10,5,3,'Fuga quia voluptatem ut nam. Aliquam magni voluptatem recusandae quasi ut ullam. Et rerum eos molestiae odio quaerat quaerat autem. Dolorem autem quis aliquid qui.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(11,8,6,'Qui quia et accusamus beatae ut. Et nostrum amet aliquam officiis doloremque iste autem iusto. Voluptas et est a dolores aliquam. Eligendi quia ex nam a eligendi.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(12,10,9,'Molestiae neque dolor voluptatibus cupiditate quaerat est mollitia. Omnis aperiam eos magnam qui libero distinctio. Facere et amet adipisci maiores dolorum eum placeat.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(13,15,8,'Vitae iure in ullam a suscipit esse tempore. Deserunt enim dicta delectus dolor. Et et quaerat natus quia adipisci est quos. Dignissimos quis odio qui natus.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(14,9,7,'Excepturi labore nihil exercitationem sunt in optio iure. Cumque dolores ut sunt laudantium distinctio saepe. Quia sit voluptas doloribus repellat. Et animi iusto atque nesciunt est ad.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(15,2,7,'Exercitationem nesciunt qui totam aut qui est eaque. Debitis iusto pariatur natus voluptas eveniet. Fuga earum incidunt velit molestias et nostrum. Repudiandae vel placeat consequuntur dolor.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(16,5,5,'Culpa rerum deserunt ipsa. Esse voluptatem nihil placeat voluptas. Ipsam voluptas totam ut est.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(17,20,9,'Praesentium ad blanditiis sed optio placeat qui. Quos ut voluptatem ullam deserunt ut explicabo.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(18,13,8,'Laudantium consequatur exercitationem maiores. Laboriosam alias dolorem pariatur pariatur illo eos reiciendis omnis. Doloremque repellendus et harum. Qui sit est tempore nemo vitae vel consequatur.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(19,20,2,'Aliquam sit molestiae eveniet eos optio est. Et at ducimus provident quasi. Est laborum non rerum.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(20,2,4,'Aspernatur et dicta quaerat quas similique. Nihil blanditiis repudiandae ipsum. Vitae et cum ut omnis eligendi nihil.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(21,10,8,'Ut suscipit et est reiciendis ut id corporis aperiam. Aut ea et quidem aut iusto voluptate vel. Magnam sit saepe libero fuga et quo.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(22,19,6,'A sed suscipit voluptatem nesciunt dolorum assumenda. Nihil necessitatibus dicta quisquam rerum maxime esse recusandae quam. Similique aspernatur nobis quo quo odio vel.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(23,4,8,'Laudantium et eveniet consequatur eos aut debitis. Impedit mollitia quasi dignissimos dicta nobis debitis delectus fugit. Vero rerum similique nam voluptas dolorem ducimus.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(24,18,7,'Sapiente vel rerum sed non ab temporibus error. Facere libero eaque omnis fugiat accusantium rerum quam. Voluptatum consequatur deleniti voluptatem reiciendis molestias et iste.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(25,7,10,'Deleniti est dolorum tempore mollitia totam non. Sed dolor ea accusamus optio impedit animi sed quo.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(26,4,3,'Officiis ex ut repellat ut corrupti a laborum architecto. Qui quasi est nam. Temporibus labore sint inventore voluptatibus quo et modi et.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(27,18,1,'Et totam rerum quo quam totam. Itaque et autem omnis soluta. Quis ipsum ut quas sunt repellat ut. Eum culpa consequatur optio fugiat.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(28,16,5,'Consequatur voluptatum et sequi recusandae sunt beatae. Quas earum sequi rem beatae deleniti vel beatae. Amet magni vero fuga omnis beatae.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(29,13,1,'Soluta laborum ullam illum. Et deserunt error velit esse corporis veritatis repudiandae. Omnis qui dicta laborum numquam.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(30,3,3,'Ut cupiditate necessitatibus nobis iusto ad non voluptatem. Enim sequi quod eos dolores laboriosam. Eos blanditiis delectus veniam velit error enim.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(31,10,9,'Iusto hic placeat delectus ratione corrupti explicabo. Molestiae culpa sequi aliquid nihil corrupti temporibus qui iste. Nihil quasi porro dolor dignissimos sit sit.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(32,11,4,'Sint et eaque tempore quod consequatur repellendus quod. Excepturi placeat soluta repellat culpa hic praesentium molestias. Velit minus eum beatae voluptate. Sit autem eaque quis at ut aut expedita.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(33,3,3,'Magni doloremque ut magni qui doloremque. Vitae eveniet quaerat ipsam et modi optio facilis cumque. Quae molestias libero consequatur nisi distinctio.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(34,15,10,'Laboriosam ea repellendus eveniet doloremque. Non iusto vel quia libero dolor aut quod. Id expedita aut officiis eligendi optio distinctio.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(35,15,2,'Eligendi quis sit amet id nemo enim. Illum doloremque explicabo voluptatem non. Dolores unde ipsa accusamus animi ex quia vero dolores.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(36,11,8,'Eos qui ullam alias voluptatum itaque consectetur. Ea voluptatem possimus ullam repellat rem in.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(37,2,2,'Qui voluptatem doloribus sint explicabo ratione aut velit. Libero velit qui in quos. Qui magnam possimus pariatur odit. Et aut vitae quaerat aut.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(38,18,9,'Dignissimos unde in eveniet nulla porro dolorem voluptates fuga. Et est distinctio voluptas odio ut quae. Voluptatem similique maxime hic sed ad culpa temporibus.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(39,9,1,'Cum omnis sunt vitae. Aliquam non temporibus dolorem ut qui dolor sed. Beatae excepturi earum sed dicta aut animi est. Nihil accusantium et cupiditate in.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(40,11,1,'Quia sunt sunt quis et. Quo recusandae voluptatibus consectetur quo quibusdam quas. Dicta commodi tempora error aut maiores. Nisi corporis et alias blanditiis accusamus.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(41,20,13,'dedededeefeffFFE','2016-03-18 18:16:42','2016-03-18 18:16:42'),
	(42,20,13,'DEDEDEDEDE','2016-03-18 18:17:11','2016-03-18 18:17:11');

/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;


# Affichage de la table migrations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;

INSERT INTO `migrations` (`migration`, `batch`)
VALUES
	('2014_10_12_000000_create_users_table',1),
	('2014_10_12_100000_create_password_resets_table',1),
	('2016_03_07_114318_create_posts_table',1),
	('2016_03_07_115232_add_columns_to_posts',1),
	('2016_03_07_120116_create_comments_table',1),
	('2016_03_08_084847_add_column_posts',1),
	('2016_03_17_182938_create_project_table',1);

/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;


# Affichage de la table password_resets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `password_resets`;

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



# Affichage de la table posts
# ------------------------------------------------------------

DROP TABLE IF EXISTS `posts`;

CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `posts_user_id_foreign` (`user_id`),
  CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;

INSERT INTO `posts` (`id`, `user_id`, `title`, `content`, `created_at`, `updated_at`)
VALUES
	(1,3,'Sint delectus hic ducimus perferendis repudiandae illo. Id voluptas eaque exercitationem eaque.','Pariatur inventore beatae dolor atque beatae veritatis molestias. Quod vero provident magni rerum ab. Nemo rerum necessitatibus qui necessitatibus eius.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(2,9,'Deserunt neque quis illum dolores hic. Voluptatem aut laborum itaque iste. Dolores dignissimos eligendi non ut et hic non veritatis. Nihil nesciunt quasi quaerat laudantium velit commodi.','Praesentium a quasi nam error. Veniam incidunt dolorem at quis minima ipsum. Animi sit sunt recusandae aliquid fugit iure.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(3,5,'Et ut sequi accusamus cumque. Molestiae quis blanditiis quod repudiandae ab illum. Excepturi atque sequi blanditiis temporibus et.','Voluptatibus architecto et sed fugiat. Consequuntur sit illo ea debitis omnis nulla aut. Corporis inventore perspiciatis non dignissimos sit maiores illo.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(4,5,'Sapiente consequatur labore sunt ratione est ab est consectetur. Quo asperiores sapiente qui. Est rem voluptatem accusantium recusandae molestiae laborum ullam modi. Eaque sed quod repellendus qui.','Provident doloremque in iure at. Neque ut dolore ipsum dolorum excepturi nihil ut. Et minima pariatur sint et accusamus quia exercitationem. Ratione et ipsam explicabo labore.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(5,4,'Quia fuga occaecati enim praesentium beatae beatae quas maxime. Nihil porro magnam suscipit suscipit culpa et excepturi. Nihil modi dolor qui nesciunt qui id.','Et non delectus laudantium dolores eos. Dolor voluptas qui ut aut reiciendis. Qui molestiae porro impedit corrupti expedita minus id. Quaerat pariatur quasi recusandae aperiam reiciendis.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(6,9,'Quisquam et officiis quia earum. Ipsam quos quaerat enim reiciendis. Voluptatum et id facilis rem alias.','Adipisci deserunt nisi aperiam et itaque. Porro qui explicabo aspernatur vitae expedita minus minus. Labore hic ut vel quod facere optio molestias. Tempora at sed modi inventore voluptas sed et.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(7,4,'Est quia consequatur exercitationem distinctio voluptatum rem. Architecto praesentium ipsam doloremque vel et consequuntur eveniet. Voluptatem et tempora nobis expedita. Nobis magnam qui ut.','Commodi est id illum voluptas omnis impedit dolores. Similique ut dolorem tenetur recusandae molestiae ea possimus.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(8,1,'Odit ut illum dolorem praesentium et dolorum iure a. Enim non veniam autem quaerat. A voluptate repudiandae vel autem ut quis.','Nihil quidem ut quia nam. Corporis optio itaque magnam iure eos est aut. Sed culpa ea nihil ducimus. Commodi veniam aspernatur suscipit accusamus.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(9,8,'Aut nisi quia nostrum veniam. Quisquam labore et voluptatem nesciunt porro iste illo. Non quia sunt aspernatur repellendus est. Veniam impedit officia et tempore.','Alias ipsum aspernatur et et reiciendis voluptatem sequi. Ut aperiam nesciunt qui tempora. Aut vitae et animi vitae aut ea odio.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(10,9,'Sit esse autem at qui animi officia. Nemo commodi ut delectus dolorem nobis sunt voluptatum. Praesentium quas odio animi veniam.','Porro voluptatibus iusto sit vero illum sapiente. Nesciunt doloremque ad atque doloribus dolorum nostrum. Eum nam libero est adipisci quis ut. Ea ex inventore eius saepe accusantium assumenda beatae.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(11,7,'Consequatur mollitia magnam aut. Consequatur ut maiores reprehenderit qui. Accusantium incidunt quae voluptatem voluptatem inventore. Sit a porro quia suscipit facere et.','Qui et omnis eaque explicabo. Tenetur est suscipit magnam eius dolore quo aspernatur sint. Quos et cupiditate voluptates qui dolorem nam nisi.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(12,8,'Qui sed porro occaecati eum nihil vitae. Fugit iste error eaque tempore. Magni quo ducimus dolores assumenda. Dolores ut distinctio est ea cum sint.','Illo mollitia incidunt et consequatur soluta cupiditate. Voluptas voluptas dolor sed aliquam et aut. Soluta iusto assumenda quas ut nisi ut quisquam. Officiis consectetur et ut et maiores iste.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(13,9,'Velit alias id est consectetur sunt. Culpa esse numquam molestias ipsa eos. Dolores autem atque vel et facilis exercitationem. Autem fugit accusamus neque.','Qui molestiae dicta alias expedita officia qui. Voluptatem nisi est repellendus deserunt ut et iure et.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(14,2,'Sunt occaecati minima quod nobis nisi vero. Pariatur quia odit ducimus sapiente earum ad quos. Commodi magnam consequatur temporibus officia.','Molestiae ullam quis minima qui placeat aut velit. Nisi praesentium quasi modi ex. Voluptatem repudiandae velit qui quibusdam architecto. Dolore et atque occaecati et nisi vitae ut.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(15,8,'Eveniet dolorem et nihil praesentium consequatur iure et. Consequuntur iure dignissimos nisi. Corporis et voluptate dolor dolores placeat et vel.','Illum autem est ut ut et iure. Cum eveniet dicta minima deleniti earum voluptas fugit. Nihil consequatur quia non.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(16,4,'Iusto quasi quasi animi adipisci labore. Nesciunt qui blanditiis explicabo est ut reprehenderit. Voluptates et nam quasi. Voluptates optio et laudantium.','Qui tempore quas dolor blanditiis. Aperiam qui pariatur nulla voluptatum et aut aut. Odit minus quidem repellat corrupti labore.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(17,5,'Fugit dolorum ad sed adipisci nostrum est. Aut impedit quibusdam repellendus atque modi.','Praesentium autem eos incidunt mollitia maxime eum. Ipsam molestiae soluta quos distinctio dicta provident.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(18,8,'Eligendi est assumenda qui aut quam necessitatibus. Qui et ut nemo enim numquam et in. Consequatur accusamus sed aut aperiam dolores omnis occaecati.','Iusto adipisci ea et. Doloribus qui cumque optio natus numquam quae occaecati dolor. Expedita est consequatur aut autem asperiores eaque.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(19,1,'Nulla hic rem est dignissimos placeat. Soluta blanditiis qui qui accusamus nihil eius. Suscipit unde similique harum voluptatem fuga.','Itaque illo alias tempore et provident maiores. Distinctio laborum alias dolores repellat ex pariatur commodi. Neque libero rem nemo enim est cumque quaerat et.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(20,1,'Iste aliquid a enim temporibus aut inventore perspiciatis. Ex ex sequi quasi. Dolorem quo ut sunt porro suscipit. Et cum beatae dicta molestiae itaque.','Aut quae sit eos deleniti alias. Ratione neque voluptate distinctio consequuntur. Minus ut est rerum.','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(21,12,'ffrfrfrfrgrgrqegregregregregre','frefrqffrqerrgerfrgqegrgrqegrqe','2016-03-18 17:49:52','2016-03-18 17:49:52'),
	(22,13,'de','de','2016-03-18 18:11:17','2016-03-18 18:11:17');

/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;


# Affichage de la table projets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `projets`;

CREATE TABLE `projets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `nomduprojet` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nom` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fonction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adresse` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tel` longtext COLLATE utf8_unicode_ci NOT NULL,
  `nom_suivi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fonction_suivi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adresse_suivi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email_suivi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tel_suivi` longtext COLLATE utf8_unicode_ci NOT NULL,
  `contexte` longtext COLLATE utf8_unicode_ci NOT NULL,
  `demande` longtext COLLATE utf8_unicode_ci NOT NULL,
  `objectif` longtext COLLATE utf8_unicode_ci NOT NULL,
  `contrainte` longtext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `validation` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `projets` WRITE;
/*!40000 ALTER TABLE `projets` DISABLE KEYS */;

INSERT INTO `projets` (`id`, `user_id`, `nomduprojet`, `nom`, `fonction`, `adresse`, `email`, `tel`, `nom_suivi`, `fonction_suivi`, `adresse_suivi`, `email_suivi`, `tel_suivi`, `contexte`, `demande`, `objectif`, `contrainte`, `created_at`, `updated_at`, `validation`)
VALUES
	(1,3,'Sit voluptas molestiae iusto possimus illum velit.','Darlene Vandervort','PDG','40908 Hickle Forks\nMyriambury, NY 98219','Misael24@Lakin.com','045-917-4899','Bria Satterfield Jr.','secretaire','46371 Konopelski Ports\nFreedabury, NE 05866','Jacques.Lang@McGlynn.com','083-261-2701x9906','Ratione expedita id sint illum culpa et et expedita. Quo aperiam sunt dolorem aut velit eos rem. Non deserunt quas totam error corporis.','Est in excepturi ut facere inventore. Saepe culpa omnis aut tempore optio officia consequatur. Cumque sed quis quia modi consequatur sit facere a. Modi et maxime ut voluptates sit.','Voluptatem quia magnam qui deserunt quasi non sapiente. Aspernatur corporis necessitatibus quos accusantium rerum vel. Exercitationem minima sequi delectus culpa.','Ullam accusamus quam aut vitae deserunt sed quae. Pariatur animi officia dicta ullam velit quia voluptas. Hic illum aut ipsum aut ab qui.','2016-03-18 17:02:57','2016-03-18 17:02:57',0),
	(2,9,'Aut possimus quia mollitia cumque.','Frank Nader','PDG','17224 Alan Glens Suite 086\nBayerborough, AR 47866-3839','nTromp@hotmail.com','067-266-8979x59022','Pietro Keeling','secretaire','42843 Smith Dale\nNew Jared, DC 02958','McLaughlin.Aditya@hotmail.com','594.522.5874','Delectus eos qui asperiores tenetur harum molestiae. Quasi maxime reiciendis omnis hic impedit enim dolorem. Ut vitae quas dolor iusto et provident. Magni nam quae modi.','Nihil dignissimos doloremque ipsam minus qui. Quo aut quis eius reprehenderit. Expedita placeat perspiciatis iste qui in quia. Rerum fuga sed ut ab voluptates perspiciatis et.','Repudiandae cumque recusandae eos nobis tenetur aut. Quo animi nam molestiae facere officia. Corrupti non veritatis perferendis nihil.','Ut cumque voluptatem sit recusandae delectus nulla nulla. Incidunt sunt dolor voluptas quos. Aut in veritatis assumenda sit.','2016-03-18 17:02:57','2016-03-18 17:02:57',0);

/*!40000 ALTER TABLE `projets` ENABLE KEYS */;
UNLOCK TABLES;


# Affichage de la table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `admin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tel` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`id`, `name`, `admin`, `tel`, `email`, `password`, `remember_token`, `created_at`, `updated_at`)
VALUES
	(1,'Eldridge Grant','0','057-673-6408','Daniel.Skyla@Kovacek.com','$2y$10$A0p3ZAYrngIcPWHl6mwZVebHoabEGK0JGGlYeMbuHhpXxV1BFARnS','xphyqj7ypU','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(2,'Prof. Virgil King MD','0','041.778.4769','qKrajcik@yahoo.com','$2y$10$O6gaoVTbmaN18JQUOabgW.WoMUVMwDxwKGkp8wW8lU7mUP9tiDHQa','81ILcftFmb','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(3,'Mr. Hans Hoeger DVM','0','+35(9)2021409518','tGislason@Balistreri.org','$2y$10$V.qpLamMqyfhGqB2ORM08eFZcmFfWMXmk.asl8eTqbBqz96ZgbZ6.','A3cCnmOR2I','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(4,'Mr. Porter Bednar','0','(394)054-9910x1557','Goyette.Maiya@Murazik.com','$2y$10$cdpgJLcnuq4xVvpGCYiZk.CY0TN8Iw6kSqgepheKyUz6whgaiOQxW','FK9cK39P7W','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(5,'Audreanne Roob','0','850.075.4913x0753','Gennaro.Lynch@Abbott.org','$2y$10$VbOxFdc6a58YSQ/B/yqFj.nq0o0ZLpwIThLtp/16i11eZ4.nt7AmW','oFHmyYxtXN','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(6,'Sabrina Littel','0','06725985956','kKoss@hotmail.com','$2y$10$SFis/fc2KlfUfTd4V3RZkeXWvANXVTC7nJPy8Z/xhSET2PgUHVIXy','HNGNwU86Q2','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(7,'Dr. Alva Considine DVM','0','530.930.1266x154','Kaylin.Hintz@Stehr.net','$2y$10$alqENQ2WN17K/T0cnHf0VeHX8ypON95zbj3RFA.QHv3WeJR.xk8.i','rW77EoryFW','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(8,'Dr. Ola Jakubowski IV','0','(951)163-9531x547','Emmalee72@Paucek.com','$2y$10$V1CWjM.Ohe8EGXkYMjjlEOh/uuc6DVc61kmfJW6SVoIs5thZinB02','keBhShtSqh','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(9,'Prof. Delbert Powlowski','0','033.698.2833x6953','Gonzalo.West@Monahan.info','$2y$10$9jBtRoNzK/exyXGhhuSy4.kPjUJeN2M8Vwwc1VnVym8S4LY1pc4JG','LNDvENiwAC','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(10,'Rosa Kessler','0','(588)975-6292x7243','Jacobi.Aileen@Doyle.com','$2y$10$HryuQuknOVmQ/VCHYeVABeFf9UgDJKQOovTFzwT7yyuozgti0YZ/e','B0FubrwIrT','2016-03-18 17:02:57','2016-03-18 17:02:57'),
	(11,'victor',NULL,NULL,'vicator6@gmail.com','$2y$10$GbuRwJ5xWbMnsIghi5y62eG5Mb.pUwS22IxLdfd2/tFNz97VXdv1y','1UW9qImseFvrLrDTEJExdGXLTfzfvdlHWk0Nu4AbLpUZbUNzhQ1ABDnTHmjB','2016-03-18 17:03:58','2016-03-18 17:13:57'),
	(12,'salut',NULL,'0699393097','salut@salut.fr','$2y$10$UNn7EXm3iRV5x8wnSLEdwuc6.tLvvNERlAGkai10zjzXMNyG/W6TO','7xrAKG6ofkE5BKOaj0vMl0v3gc2VbZ5Yzf2RHaqyx6yRtjCpBHWyzULBI7DJ','2016-03-18 17:27:33','2016-03-18 18:04:18'),
	(13,'vic chanson',NULL,NULL,'vicator63@gmail.com','$2y$10$RcP.5v05ploo.WmqK19hCuY3PUrgNui1tRGybXBgP4IA5LrvY9bT2',NULL,'2016-03-18 18:06:53','2016-03-18 18:06:53');

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
